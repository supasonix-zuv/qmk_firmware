#define QMK_VERSION "53f171-dirty"
#define QMK_BUILDDATE "2021-02-07-03:51:01"
#define CHIBIOS_VERSION "breaking_2020_q1"
#define CHIBIOS_CONTRIB_VERSION "breaking_2020_q1"